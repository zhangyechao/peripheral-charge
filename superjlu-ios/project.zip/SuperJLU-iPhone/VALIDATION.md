# 验证记录

验证环境：Windows；便携版 CPython 3.13.11；原 APK 核心 1.3.4。iOS 运行库固定为 Python-Apple-support 3.13-b14，已下载并核对官方 SHA-256、查看归档结构；未在 Windows 解包运行 Apple 二进制。

`tools/test_port.py`：11 项通过。

- 原网页成功返回，包含 iOS 日历导出和输入框适配。
- 示例课表、成绩接口可读取；iCalendar 含实际事件。
- 登录状态接口可读取；不代表真实学校认证已通过。
- 偏好设置写入后可读取。
- 无令牌请求返回 401；错误 Host 返回 403；服务器只绑定 `127.0.0.1`。
- 原加密文件接口在桌面桥接替身下完成 AES-GCM 加密/解密，并能检测密文篡改。
- 模拟钥匙串失败后没有写出明文或加密文件。
- Pillow 13.0.0 能运行原验证码算法和 JPEG 解码；这是合成图兼容性检查，不是学校真实验证码准确率测试。

测试使用临时目录和示例数据，未登录学校，未读取用户校园账号。测试中的加密操作由桌面 cryptography 库提供，用于验证 Python 接口契约，**不等于已验证 Swift CryptoKit / iOS Keychain 桥接**。

尚未完成：Xcode 编译与链接、原生单元测试、模拟器启动、iPhone 安装、钥匙串真机验证、真实账号同步、VPN 和单点登录、分享和下载真机验收。没有生成 IPA，没有 App Store / TestFlight 发布。

桌面复现：使用 Python 3.13，把 cryptography 和 Pillow 13.0.0 安装到 `.tools/testdeps`，然后运行 `python tools/test_port.py`。此测试目录不进入应用或交付 ZIP。
