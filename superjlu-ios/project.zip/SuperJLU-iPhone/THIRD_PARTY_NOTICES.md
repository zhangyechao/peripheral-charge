# 来源与第三方组件

SuperJLU 核心来自用户提供的 APK，版本号为 1.3.4。项目：
https://github.com/Runa-Asahi/SuperJLU

上游 LICENSE 网页所显示的许可如下（检索时的页面内容；实时源码地址返回 404）：

> MIT License
>
> Copyright (c) 2026 Runa-Asahi
>
> Permission is hereby granted, free of charge, to any person obtaining a copy of this software, to deal in the Software without restriction. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.

来源：https://github.com/Runa-Asahi/SuperJLU/blob/main/LICENSE

提取的 openpyxl、et_xmlfile、xlrd 保留各自 `.dist-info` 中的许可和元数据。它们与 Python、Pillow 的原作者保留各自权利。

Python 运行库通过 BeeWare Python-Apple-support 获取；Pillow 通过 PyPI 官方发行包获取，准备脚本保留发行包内的许可。构建产物应随附这些许可。当前 ZIP 不包含下载的运行库或本机测试依赖。

本工程新增的 iOS 宿主、适配与构建脚本采用 MIT 许可。允许自由使用、复制、修改及分发，保留本许可声明；软件按现状提供，不附带担保。
