#!/bin/bash
set -e
cd "$(dirname "$0")"
python3 tools/prepare_mac.py
open SuperJLU.xcodeproj
