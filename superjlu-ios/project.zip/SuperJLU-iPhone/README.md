# SuperJLU iPhone 移植工程（实验版）

这是从提供的 SuperJLU 1.3.4 Android 包提取核心逻辑后制作的 iOS 工程。已在云端通过 Xcode 编译并生成 ARM64 iPhone IPA；运行验证记录见 `VALIDATION.md`。IPA 需要使用自己的 Apple 账号签名安装，尚未在用户的 iPhone 上验收。原 APK 保持原样。

## 当前已经做了什么

- 提取并复用原应用 Python 3.13 字节码、网页界面、课表/成绩/考试等业务模块，以及纯 Python 表格处理库。
- 新增 UIKit + WKWebView 界面和 Python 内嵌启动器。后端设计为直接运行在 iPhone 内，仅监听本机回环地址，无需电脑常开。
- 新增 CryptoKit AES-GCM 与 iOS Keychain 的桥接代码，兼容原加密文件格式。钥匙串不可用时中止保存，避免退回明文存储。
- 新增 CommonCrypto AES-CFB 适配，供原校园 WebVPN 地址编码模块使用。
- 新增 iCalendar 与文字分享、下载文件分享、外部网站打开和 iPhone 输入框适配。
- 保留原验证码识别流程，Mac 准备脚本下载经过 SHA-256 校验的官方 Pillow 13.0.0 iOS 库。未打包 Android 的 ELF / `.so` 文件。
- Windows 上测试了复用后的后端；具体范围见 `VALIDATION.md`。

## Windows + iPhone 安装

使用同目录交付的 `SuperJLU-1.3.4-iOS-unsigned.ipa`，在 Windows 的 [Sideloadly](https://sideloadly.io/) 中选择连接的 iPhone，导入 IPA，并使用自己的 Apple 账号签名安装。手机按提示信任开发者和开启开发者模式。具体步骤在工程旁的 `SuperJLU-iPhone-安装说明.txt`。

把未签名 IPA 发到手机后直接点击不能安装。免费账号签名通常有效 7 天，需要再次签名或配置自动刷新。应用安装后在手机本机运行，不要求电脑常开。参考 [Sideloadly 官方 FAQ](https://sideloadly.io/faq.html)。

## 云端构建 / Mac 开发

没有 Mac 时可使用 GitHub 的 macOS runner。`cloud/build-ipa.yml` 已发布到仓库 `.github/workflows/superjlu-ios.yml`，完整源码 ZIP 位于 `superjlu-ios/project.zip`，在 `codex/superjlu-ios-build` 分支推送相关文件后会触发构建。

构建先运行 12 项后端测试，再调用 Xcode 编译 iPhone ARM64 版本，并检查 Mach-O 平台和运行库文件。模拟器启动检查通过后上传 `SuperJLU-1.3.4-iOS-unsigned.ipa`、构建报告及截图，可从 Actions 的 Artifacts 下载。它尚未用个人 Apple 账号签名；云端不需要 Apple 密码。

需要完整 Xcode、可用的 iOS SDK、Python 3.12 或更新版本。目标为 iOS 16 或更新版本。

1. 把整个工程目录复制到 Mac，打开终端进入该目录。
2. 运行 `python3 tools/prepare_mac.py`。脚本会下载并验证 Python iOS 运行库及 Pillow 的真机、模拟器版本。
3. 打开 `SuperJLU.xcodeproj`，选中 SuperJLU target，在 Signing & Capabilities 选择自己的 Team，并把 Bundle Identifier 改为自己的唯一标识。
4. 连接并信任 iPhone；按 Xcode 提示启用开发者模式。选择手机作为运行目标，点 Run，完成首次编译、签名和调试。
5. 若要生成供安装的 IPA，先完成真机验收，再通过 Product → Archive → Distribute App 选择与自己的签名资格相符的分发方式。不同分发方式要求不同，不能把未签名压缩包直接当作可安装 App。

不需要把 Apple ID 密码或证书私钥发给助手。当前没有创建 Apple 开发者资源，也没有上传 App Store 或 TestFlight。

## 仍需真机确认 / 未移植功能

- 已通过 Xcode 的 iPhone 真机目标和模拟器目标编译；实际运行检查结果见 `VALIDATION.md`。用户设备的签名、安装、钥匙串和系统版本兼容性仍需真机验收。
- 未使用真实校园账号测试登录、微信二次验证、校外 VPN、课表刷新、实时空教室和通知。没有把示例数据冒充真实数据；正式启动不会自动导入示例数据。
- 内置浏览器跳转到外部网站后，单点登录 Cookie 共享和跳转结果需要单独验证，可能需要重新登录。
- Android 小组件、锁屏通知、后台常驻没有移植到 iOS。切到后台后系统可以暂停应用。
- 这是开发安装工程，暂未提供 App Store 所需的完整图标、隐私清单与商店素材，也不保证通过审核。
- 账号和缓存保存在应用沙箱；数据目录不备份到 iCloud，密钥仅限本机。重新安装或换机后可能需要重新登录。
- 上游核心逻辑只有从 APK 提取的字节码，不能用 Python 3.14/3.15 替代 3.13。拿到原始源码后应改为源码构建。

## 文件

`iOS/` 是新写的原生宿主；`app/ios_bootstrap.py` 是适配入口；`app/jlu_toolkit/` 是原包提取内容；`tools/` 包含提取、工程生成、Mac 准备和测试脚本；`provenance.json` 记录原包指纹。

参考：

- [上游项目](https://github.com/Runa-Asahi/SuperJLU)（迁移时实时源码下载返回 404；网页缓存能读到项目说明）
- [Python 官方 iOS 内嵌说明](https://docs.python.org/3.13/using/ios.html)
- [BeeWare Python 3.13-b14 运行库](https://github.com/beeware/Python-Apple-support/releases/tag/3.13-b14)
- [Pillow 官方发行包](https://pypi.org/project/pillow/13.0.0/)
- [Apple：向已注册设备分发 App](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices)
