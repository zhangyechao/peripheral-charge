"""Create a source delivery ZIP, excluding tools, downloads and test data."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {".tools", ".analysis", "Vendor", "build", "DerivedData", "__pycache__", ".git"}


def main():
    output = ROOT.parent / "SuperJLU-iPhone-移植工程.zip"
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob("*")):
            relative = path.relative_to(ROOT)
            if not path.is_file() or any(part in EXCLUDED for part in relative.parts):
                continue
            name = "SuperJLU-iPhone/" + relative.as_posix()
            if path.suffix == ".command":
                entry = zipfile.ZipInfo(name)
                entry.create_system = 3
                entry.external_attr = 0o100755 << 16
                archive.writestr(entry, path.read_bytes().replace(b"\r\n", b"\n"))
            else:
                archive.write(path, name)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert not any(n.endswith((".so", ".dll", ".exe", ".ipa", ".apk")) for n in archive.namelist())
        print("Files:", len(archive.namelist()))
    print(output)
    print("Bytes:", output.stat().st_size)
    print("SHA256:", hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
