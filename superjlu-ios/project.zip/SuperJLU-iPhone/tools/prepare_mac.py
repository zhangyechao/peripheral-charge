"""Download and unpack the pinned Apple runtime without requiring Homebrew."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
URL = "https://github.com/beeware/Python-Apple-support/releases/download/3.13-b14/Python-3.13-iOS-support.b14.tar.gz"
SHA256 = "8b5cb76ef8d8a2946052479358eeec9d54b4496cb60920e175ec1489b5cf7963"


def main():
    if sys.platform != "darwin":
        raise SystemExit("Run this preparation script on a Mac with full Xcode installed.")
    vendor = ROOT / "Vendor"
    vendor.mkdir(exist_ok=True)
    archive = vendor / "Python-3.13-iOS-support.b14.tar.gz"
    if not archive.exists():
        print("Downloading Python 3.13 iOS runtime (about 32 MB)…")
        urllib.request.urlretrieve(URL, archive)
    if hashlib.sha256(archive.read_bytes()).hexdigest() != SHA256:
        raise SystemExit("Runtime checksum mismatch. Remove only the downloaded archive and retry.")
    with tarfile.open(archive) as tar:
        members = [m for m in tar.getmembers() if m.name == "Python.xcframework" or m.name.startswith("Python.xcframework/")]
        # data_filter rejects absolute paths, escaping symlinks and special files.
        if not hasattr(tarfile, "data_filter"):
            raise SystemExit("Use Python 3.12 or newer on this Mac for safe archive extraction.")
        tar.extractall(vendor, members=members, filter="data")
    wheels = json.loads((ROOT / "tools/pillow-wheels.json").read_text())
    for wheel in wheels:
        if "-ios_" not in wheel["filename"]:
            continue
        platform = wheel["filename"].split("-ios_13_0_", 1)[1].removesuffix(".whl")
        destination = vendor / "pillow" / platform
        download = vendor / wheel["filename"]
        if not download.exists():
            print("Downloading", wheel["filename"])
            urllib.request.urlretrieve(wheel["url"], download)
        if hashlib.sha256(download.read_bytes()).hexdigest() != wheel["sha256"]:
            raise SystemExit("Pillow checksum mismatch: " + wheel["filename"])
        with zipfile.ZipFile(download) as zipped:
            for entry in zipped.infolist():
                if entry.is_dir():
                    continue
                target = (destination / entry.filename).resolve()
                if not target.is_relative_to(destination.resolve()):
                    raise SystemExit("Unsafe wheel path")
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(zipped.read(entry))
    print("Ready. Open SuperJLU.xcodeproj, choose your signing team and connect the iPhone.")


if __name__ == "__main__":
    main()
