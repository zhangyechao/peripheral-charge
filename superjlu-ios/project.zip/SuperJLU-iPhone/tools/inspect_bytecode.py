"""Read bytecode without importing or executing the original app."""
import dis
import marshal
from pathlib import Path
import types

root = Path(__file__).resolve().parents[1]
out = root / ".analysis"
out.mkdir(exist_ok=True)
for name in ("ui", "secure_store", "sessions", "network", "core", "captcha_solver", "captcha_util", "web_login"):
    code = marshal.loads((root / "app/jlu_toolkit" / (name + ".pyc")).read_bytes()[16:])
    with (out / (name + ".txt")).open("w", encoding="utf-8") as f:
        dis.dis(code, file=f)
    imports = [i.argval for i in dis.get_instructions(code) if i.opname == "IMPORT_NAME"]
    functions = [c.co_name for c in code.co_consts if isinstance(c, types.CodeType)]
    print(name, "imports=", imports, "functions=", functions)
