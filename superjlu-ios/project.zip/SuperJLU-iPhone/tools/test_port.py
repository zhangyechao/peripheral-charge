"""Desktop checks of recovered backend and bridge contract, not iOS device tests."""
from pathlib import Path
import http.client
import json
import secrets
import sys
import tempfile
import unittest
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "app"), str(ROOT / ".tools/testdeps")]
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import ios_bootstrap


class DesktopCrypto:
    """Test double for the CryptoKit C bridge; never included in the application."""
    secret = secrets.token_bytes(32)

    @classmethod
    def key(cls, create):
        return cls.secret

    @staticmethod
    def encrypt(key, nonce, data, aad):
        return AESGCM(key).encrypt(nonce, data, aad)

    @staticmethod
    def decrypt(key, nonce, data, aad):
        return AESGCM(key).decrypt(nonce, data, aad)

    @staticmethod
    def cfb(key, iv, data, encrypt):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms
        from cryptography.hazmat.decrepit.ciphers.modes import CFB
        cipher = Cipher(algorithms.AES(key), CFB(iv))
        operation = cipher.encryptor() if encrypt else cipher.decryptor()
        return operation.update(data) + operation.finalize()


class PortTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.url = urlsplit(ios_bootstrap.start(cls.temp.name, native=DesktopCrypto, demo=True))
        status, headers, _ = cls.request("GET", "/?" + cls.url.query, authenticated=False)
        assert status in (302, 303)
        cls.cookie = headers["Set-Cookie"].split(";", 1)[0]

    @classmethod
    def tearDownClass(cls):
        ios_bootstrap.stop()
        cls.temp.cleanup()

    @classmethod
    def request(cls, method, path, body=None, authenticated=True, extra=None):
        headers = {}
        if authenticated:
            headers["Cookie"] = cls.cookie
        if body is not None:
            body = json.dumps(body)
            headers["Content-Type"] = "application/json"
        headers.update(extra or {})
        connection = http.client.HTTPConnection(cls.url.hostname, cls.url.port, timeout=10)
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        result = response.status, dict(response.getheaders()), response.read()
        connection.close()
        return result

    def test_page(self):
        status, _, body = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn(b"SuperJLU-(Android|iOS)", body)
        self.assertIn(b"font-size:16px", body)

    def test_no_auth_cannot_read_student_data(self):
        status, _, _ = self.request("GET", "/api/data", authenticated=False)
        self.assertEqual(status, 401)

    def test_wrong_host_rejected(self):
        status, _, _ = self.request("GET", "/api/data", extra={"Host": "evil.example"})
        self.assertEqual(status, 403)

    def test_sample_schedule_and_grades(self):
        status, _, body = self.request("GET", "/api/data")
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertIsInstance(data, dict)
        self.assertTrue(data.get("courses") or data.get("schedule"), list(data))
        self.assertTrue(data.get("grades"), list(data))

    def test_calendar_download(self):
        status, _, body = self.request("GET", "/api/ics")
        self.assertEqual(status, 200)
        self.assertTrue(body.startswith(b"BEGIN:VCALENDAR"))
        self.assertIn(b"BEGIN:VEVENT", body)

    def test_preferences_roundtrip(self):
        status, _, _ = self.request("POST", "/api/prefs", {"set": {"jlu-theme": "dark"}})
        self.assertEqual(status, 200)
        status, _, body = self.request("GET", "/api/prefs")
        self.assertEqual(status, 200)
        self.assertIn("dark", body.decode())

    def test_secure_store_encrypts_and_detects_tampering(self):
        from jlu_toolkit.secure_store import SecretFile, SecureStoreError
        item = SecretFile(Path(self.temp.name), "test-secret")
        data = {"cookie": "private-fixture-value"}
        path = item.save(data)
        self.assertEqual(path.suffix, ".enc")
        self.assertNotIn(b"private-fixture-value", path.read_bytes())
        self.assertEqual(item.load(), data)
        blob = path.read_bytes()
        path.write_bytes(blob[:-1] + bytes([blob[-1] ^ 1]))
        with self.assertRaises(SecureStoreError):
            item.load()

    def test_key_failure_never_saves_plaintext(self):
        from jlu_toolkit.secure_store import SecretFile
        original = DesktopCrypto.key
        try:
            DesktopCrypto.key = staticmethod(lambda create: None)
            item = SecretFile(Path(self.temp.name), "failed-secret")
            with self.assertRaises(Exception):
                item.save({"password": "must-not-write"})
            self.assertFalse(item.plain_path.exists())
            self.assertFalse(item.enc_path.exists())
        finally:
            DesktopCrypto.key = original

    def test_server_loopback_only(self):
        self.assertEqual(ios_bootstrap._server.server_address[0], "127.0.0.1")

    def test_webvpn_url_codec_and_partial_blocks(self):
        from jlu_toolkit import campus
        from ios_ciphers import Cipher, AES, CFB
        for url in ("https://iedu.jlu.edu.cn/jwapp/test?q=1", "http://lib.jlu.edu.cn:8080/a#b"):
            self.assertEqual(campus.vpn_url_decode(campus.vpn_url(url)), url)
        key, iv = bytes(range(16)), bytes(range(16))
        plaintext = b"an-example-hostname.jlu.edu.cn"
        cipher = Cipher(AES(key), CFB(iv)).encryptor()
        encrypted = cipher.update(plaintext[:3]) + cipher.update(plaintext[3:]) + cipher.finalize()
        self.assertEqual(encrypted, DesktopCrypto.cfb(key, iv, plaintext, True))
        with self.assertRaises(ValueError):
            cipher.update(b"again")

    def test_login_state_is_available(self):
        status, _, body = self.request("GET", "/api/login")
        self.assertEqual(status, 200)
        self.assertIsInstance(json.loads(body), dict)

    def test_pillow_captcha_compatibility(self):
        import io
        from PIL import Image, ImageDraw
        from jlu_toolkit.captcha_solver import solve_captcha
        fixture = Image.new("RGB", (100, 35), "white")
        ImageDraw.Draw(fixture).text((4, 4), "1234", fill="black", font_size=24)
        stream = io.BytesIO()
        fixture.save(stream, format="JPEG")
        result = solve_captcha(stream.getvalue())
        self.assertTrue(result is None or (len(result) == 4 and result.isdigit()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
