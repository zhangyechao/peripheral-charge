"""Generate a dependency-free Xcode project, including a shared build scheme."""
import hashlib
import json
import plistlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def ident(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()


def quote(value):
    return json.dumps(value, ensure_ascii=False)


def main():
    objects = []

    def add(name, body):
        objects.append(f"\t{ident(name)} = {{ {body} }};")
        return ident(name)

    def refs(items):
        return "(" + ", ".join(ident(i) for i in items) + ");"

    sources = ["iOS/App.swift", "iOS/SJCrypto.swift", "iOS/PythonRuntime.m"]
    files = sources + ["iOS/PythonRuntime.h", "iOS/SuperJLU-Bridging-Header.h", "iOS/Info.plist", "app", "Vendor/Python.xcframework"]
    for path in files:
        kind = {".swift": "sourcecode.swift", ".m": "sourcecode.c.objc", ".h": "sourcecode.c.h", ".plist": "text.plist.xml", ".xcassets": "folder.assetcatalog", ".xcframework": "wrapper.xcframework"}.get(Path(path).suffix, "folder")
        add(path, f'isa = PBXFileReference; lastKnownFileType = {kind}; path = {quote(path)}; sourceTree = "<group>";')
    add("product", 'isa = PBXFileReference; explicitFileType = wrapper.application; path = SuperJLU.app; sourceTree = BUILT_PRODUCTS_DIR;')
    add("products", "isa = PBXGroup; children = " + refs(["product"]) + ' name = Products; sourceTree = "<group>";')
    add("main", "isa = PBXGroup; children = " + refs(files + ["products"]) + ' sourceTree = "<group>";')
    for path in sources + ["app", "Vendor/Python.xcframework"]:
        add("build:" + path, f"isa = PBXBuildFile; fileRef = {ident(path)};")
    add("embedPython", f'isa = PBXBuildFile; fileRef = {ident("Vendor/Python.xcframework")}; settings = {{ ATTRIBUTES = (CodeSignOnCopy, RemoveHeadersOnCopy); }};')
    add("sources", "isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = " + refs(["build:" + p for p in sources]) + " runOnlyForDeploymentPostprocessing = 0;")
    add("resources", "isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = " + refs(["build:app"]) + " runOnlyForDeploymentPostprocessing = 0;")
    add("frameworks", "isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = " + refs(["build:Vendor/Python.xcframework"]) + " runOnlyForDeploymentPostprocessing = 0;")
    add("embed", "isa = PBXCopyFilesBuildPhase; buildActionMask = 2147483647; dstPath = \"\"; dstSubfolderSpec = 10; files = " + refs(["embedPython"]) + ' name = "Embed Frameworks"; runOnlyForDeploymentPostprocessing = 0;')
    script = 'set -e\nsource "$PROJECT_DIR/Vendor/Python.xcframework/build/utils.sh"\nexport EXPANDED_CODE_SIGN_IDENTITY="${EXPANDED_CODE_SIGN_IDENTITY:--}"\ninstall_stdlib Vendor/Python.xcframework\nprocess_dylibs Vendor/Python.xcframework python/lib/python3.13/lib-dynload\n'
    script += 'if [ "$EFFECTIVE_PLATFORM_NAME" = "-iphoneos" ]; then\n  WHEEL_PLATFORM="arm64_iphoneos"\nelse\n  WHEEL_PLATFORM="${ARCHS}_iphonesimulator"\nfi\nmkdir -p "$CODESIGNING_FOLDER_PATH/app_packages"\nrsync -a --delete "$PROJECT_DIR/Vendor/pillow/$WHEEL_PLATFORM/" "$CODESIGNING_FOLDER_PATH/app_packages/"\nprocess_dylibs Vendor/Python.xcframework app_packages\n'
    add("pythonPhase", f'isa = PBXShellScriptBuildPhase; alwaysOutOfDate = 1; buildActionMask = 2147483647; files = (); inputPaths = (); outputPaths = (); name = "Install Python Runtime"; runOnlyForDeploymentPostprocessing = 0; shellPath = /bin/bash; shellScript = {quote(script)};')
    common = {
        "CLANG_ENABLE_MODULES": "YES", "CLANG_ENABLE_OBJC_ARC": "YES",
        "CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER": "NO",
        "SWIFT_VERSION": "5.0", "IPHONEOS_DEPLOYMENT_TARGET": "16.0",
        "SDKROOT": "iphoneos", "ENABLE_USER_SCRIPT_SANDBOXING": "NO",
        "CODE_SIGN_STYLE": "Automatic", "PRODUCT_NAME": "SuperJLU",
        "PRODUCT_MODULE_NAME": "SuperJLUiOS", "PRODUCT_BUNDLE_IDENTIFIER": "cn.superjlu.personal.ios",
        "INFOPLIST_FILE": "iOS/Info.plist", "GENERATE_INFOPLIST_FILE": "NO",
        "TARGETED_DEVICE_FAMILY": "1,2", "SUPPORTS_MACCATALYST": "NO",
        "SWIFT_OBJC_BRIDGING_HEADER": "iOS/SuperJLU-Bridging-Header.h",
        "SWIFT_OBJC_INTERFACE_HEADER_NAME": "SuperJLUiOS-Swift.h",
        "HEADER_SEARCH_PATHS": '"$(BUILT_PRODUCTS_DIR)/Python.framework/Headers"',
        "FRAMEWORK_SEARCH_PATHS": '$(inherited) "$(PROJECT_DIR)/Vendor"',
        "LD_RUNPATH_SEARCH_PATHS": "$(inherited) @executable_path/Frameworks",
        "CURRENT_PROJECT_VERSION": "1", "MARKETING_VERSION": "1.3.4",
        "ENABLE_BITCODE": "NO", "ONLY_ACTIVE_ARCH": "YES",
    }
    for mode in ("Debug", "Release"):
        settings = dict(common)
        settings["SWIFT_OPTIMIZATION_LEVEL"] = "-Onone" if mode == "Debug" else "-O"
        settings["DEBUG_INFORMATION_FORMAT"] = "dwarf" if mode == "Debug" else "dwarf-with-dsym"
        settings["GCC_OPTIMIZATION_LEVEL"] = "0" if mode == "Debug" else "s"
        body = " ".join(f"{k} = {quote(v)};" for k, v in settings.items())
        add("target:" + mode, f"isa = XCBuildConfiguration; buildSettings = {{ {body} }}; name = {mode};")
        add("project:" + mode, f"isa = XCBuildConfiguration; buildSettings = {{}}; name = {mode};")
    for scope in ("target", "project"):
        add(scope + "Configs", "isa = XCConfigurationList; buildConfigurations = " + refs([scope + ":Debug", scope + ":Release"]) + " defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;")
    add("target", f'isa = PBXNativeTarget; buildConfigurationList = {ident("targetConfigs")}; buildPhases = {refs(["sources", "frameworks", "resources", "pythonPhase", "embed"])} buildRules = (); dependencies = (); name = SuperJLU; productName = SuperJLU; productReference = {ident("product")}; productType = "com.apple.product-type.application";')
    add("project", f'isa = PBXProject; attributes = {{ LastUpgradeCheck = 1600; }}; buildConfigurationList = {ident("projectConfigs")}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en, Base, "zh-Hans"); mainGroup = {ident("main")}; productRefGroup = {ident("products")}; projectDirPath = ""; projectRoot = ""; targets = ({ident("target")});')
    project = ROOT / "SuperJLU.xcodeproj"
    project.mkdir(exist_ok=True)
    (project / "project.pbxproj").write_text("// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n" + "\n".join(objects) + f"\n}}; rootObject = {ident('project')}; }}\n", encoding="utf-8")
    schemes = project / "xcshareddata/xcschemes"
    schemes.mkdir(parents=True, exist_ok=True)
    reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ident("target")}" BuildableName="SuperJLU.app" BlueprintName="SuperJLU" ReferencedContainer="container:SuperJLU.xcodeproj"/>'
    (schemes / "SuperJLU.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{reference}</BuildActionEntry></BuildActionEntries></BuildAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''', encoding="utf-8")
    info = {
        "CFBundleDisplayName": "SuperJLU", "CFBundleExecutable": "$(EXECUTABLE_NAME)",
        "CFBundleIdentifier": "$(PRODUCT_BUNDLE_IDENTIFIER)", "CFBundleName": "$(PRODUCT_NAME)",
        "CFBundlePackageType": "APPL", "CFBundleInfoDictionaryVersion": "6.0",
        "CFBundleShortVersionString": "$(MARKETING_VERSION)", "CFBundleVersion": "$(CURRENT_PROJECT_VERSION)",
        "LSRequiresIPhoneOS": True, "UILaunchScreen": {},
        "UISupportedInterfaceOrientations": ["UIInterfaceOrientationPortrait", "UIInterfaceOrientationLandscapeLeft", "UIInterfaceOrientationLandscapeRight"],
        "NSAppTransportSecurity": {"NSAllowsLocalNetworking": True},
    }
    (ROOT / "iOS/Info.plist").write_bytes(plistlib.dumps(info))
    print("Created SuperJLU.xcodeproj and Info.plist")


if __name__ == "__main__":
    main()
