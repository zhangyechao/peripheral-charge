"""Recover portable resources from the user-supplied Android archive."""
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def unpack(archive, destination, allow=lambda name: True):
    destination = destination.resolve()
    for entry in archive.infolist():
        if entry.is_dir() or not allow(entry.filename):
            continue
        target = (destination / entry.filename).resolve()
        if not target.is_relative_to(destination):
            raise ValueError("Unsafe archive path")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.read(entry))


def main():
    source = Path(sys.argv[1])
    with zipfile.ZipFile(source) as apk:
        app = apk.read("assets/chaquopy/app.imy")
        unpack(zipfile.ZipFile(io.BytesIO(app)), ROOT / "app",
               lambda name: name.startswith("jlu_toolkit/"))
        dependencies = zipfile.ZipFile(io.BytesIO(
            apk.read("assets/chaquopy/requirements-common.imy")))
        # These are pure Python. Android ELF libraries must never enter an IPA.
        roots = ("openpyxl", "et_xmlfile", "xlrd")
        unpack(dependencies, ROOT / "app", lambda name:
               any(name.startswith(root + "/") or
                   name.startswith(root + "-") for root in roots))
        (ROOT / "app" / "cacert.pem").write_bytes(apk.read("assets/chaquopy/cacert.pem"))
    info = {
        "source_name": source.name,
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "app_imy_sha256": hashlib.sha256(app).hexdigest(),
        "python": "CPython 3.13", "app_version": "1.3.4",
        "upstream": "https://github.com/Runa-Asahi/SuperJLU",
        "status": "Experimental iOS port; no signed IPA; requires Mac validation",
    }
    (ROOT / "provenance.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    print("Extracted portable app and spreadsheet modules; Android native binaries excluded.")


if __name__ == "__main__":
    main()
