"""Build on macOS, verify the device executable, then package an unsigned IPA.

The resulting archive must be signed for the user's device before installation.
No Apple account, certificate or provisioning profile is used by this script.
"""
import argparse
import hashlib
import json
from pathlib import Path
import plistlib
import shutil
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def verify_device_app(app):
    info = plistlib.loads((app / "Info.plist").read_bytes())
    if "iPhoneOS" not in info.get("CFBundleSupportedPlatforms", []):
        raise ValueError("The application is not an iPhone device build")
    executable = info["CFBundleExecutable"]
    if not executable or Path(executable).name != executable:
        raise ValueError("Invalid bundle executable")
    binary = app / executable
    data = binary.read_bytes()
    # This build intentionally targets a thin ARM64 iPhone binary.
    if len(data) < 32 or data[:4] != b"\xcf\xfa\xed\xfe":
        raise ValueError("The executable is not a compiled 64-bit Mach-O file")
    _, cpu, _, filetype, commands, size, _, _ = struct.unpack_from("<8I", data)
    if cpu != 0x0100000C or filetype != 2:
        raise ValueError("Expected an ARM64 executable")
    if size > len(data) - 32:
        raise ValueError("Invalid Mach-O load commands")
    offset = 32
    platforms = []
    for _ in range(commands):
        if offset + 8 > 32 + size:
            raise ValueError("Truncated Mach-O command")
        command, length = struct.unpack_from("<II", data, offset)
        if length < 8 or offset + length > 32 + size:
            raise ValueError("Invalid Mach-O command length")
        if command == 0x32 and length >= 24:  # LC_BUILD_VERSION
            platforms.append(struct.unpack_from("<I", data, offset + 8)[0])
        offset += length
    if platforms != [2]:  # PLATFORM_IOS, not PLATFORM_IOSSIMULATOR (7).
        raise ValueError(f"Expected an iOS device platform; got {platforms}")
    if not (app / "app/ios_bootstrap.py").is_file():
        raise ValueError("Missing embedded SuperJLU application")
    if not (app / "Frameworks/Python.framework/Python").is_file():
        raise ValueError("Missing Python framework")
    for path in app.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix in (".so", ".apk", ".exe", ".dll"):
            raise ValueError(f"Unexpected unprocessed or foreign binary: {path.name}")
        if path.suffix == ".fwork":
            target = (app / path.read_text().strip()).resolve()
            if not target.is_relative_to(app.resolve()) or not target.is_file():
                raise ValueError(f"Unresolved framework marker: {path.name}")
    return info


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle-id", default="cn.superjlu.personal.ios")
    args = parser.parse_args()
    if sys.platform != "darwin" or shutil.which("xcodebuild") is None:
        raise SystemExit("A macOS machine with full Xcode is required to compile the IPA.")
    subprocess.run([sys.executable, str(ROOT / "tools/prepare_mac.py")], check=True)
    output = ROOT / "build"
    output.mkdir(exist_ok=True)
    derived = output / "DerivedData"
    command = [
        "xcodebuild", "-project", str(ROOT / "SuperJLU.xcodeproj"),
        "-scheme", "SuperJLU", "-configuration", "Release",
        "-sdk", "iphoneos", "-destination", "generic/platform=iOS",
        "-derivedDataPath", str(derived), "build",
        "ARCHS=arm64", "ONLY_ACTIVE_ARCH=YES", "CODE_SIGNING_ALLOWED=NO",
        "CODE_SIGNING_REQUIRED=NO", "CODE_SIGN_IDENTITY=",
        "PRODUCT_BUNDLE_IDENTIFIER=" + args.bundle_id,
    ]
    subprocess.run(command, check=True, cwd=ROOT)
    app = derived / "Build/Products/Release-iphoneos/SuperJLU.app"
    info = verify_device_app(app)
    artifact = output / "SuperJLU-1.3.4-iOS-unsigned.ipa"
    with tempfile.TemporaryDirectory(prefix="ipa-", dir=output) as temp:
        payload = Path(temp) / "Payload"
        payload.mkdir()
        shutil.copytree(app, payload / app.name, symlinks=True)
        subprocess.run(["ditto", "-c", "-k", "--sequesterRsrc", "--keepParent",
                        str(payload), str(artifact)], check=True)
    report = {
        "artifact": artifact.name,
        "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
        "bundle_id": info["CFBundleIdentifier"], "architecture": "arm64",
        "platform": "iphoneos", "signed_for_installation": False,
        "physical_device_tested": False,
        "next_step": "Sign and install from Windows using your own Apple account.",
    }
    (output / "build-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
