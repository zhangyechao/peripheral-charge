"""Launch the native app in an iPhone simulator and check its embedded runtime."""
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def run(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def main():
    output = ROOT / "build"
    derived = output / "Simulator"
    bundle_id = "cn.superjlu.personal.ios"
    # Simulator securityd reads entitlements from a Mach-O section, unlike a
    # physical device. Embed the test identity when linking this target only.
    identity = "SUPERJLUTS." + bundle_id
    entitlements = output / "simulator.entitlements"
    entitlements.write_bytes(plistlib.dumps({
        "application-identifier": identity,
        "com.apple.developer.team-identifier": "SUPERJLUTS",
        "keychain-access-groups": [identity],
    }))
    run("xcodebuild", "-project", str(ROOT / "SuperJLU.xcodeproj"),
        "-scheme", "SuperJLU", "-configuration", "Release", "-sdk", "iphonesimulator",
        "-destination", "generic/platform=iOS Simulator", "-derivedDataPath", str(derived),
        "build", "ARCHS=arm64", "ONLY_ACTIVE_ARCH=YES", "CODE_SIGNING_ALLOWED=NO",
        "CODE_SIGNING_REQUIRED=NO", "CODE_SIGN_IDENTITY=", "ENABLE_DEBUG_DYLIB=NO",
        "PRODUCT_BUNDLE_IDENTIFIER=" + bundle_id,
        'OTHER_LDFLAGS=$(inherited) -Xlinker -sectcreate -Xlinker __TEXT -Xlinker __entitlements -Xlinker "$(PROJECT_DIR)/build/simulator.entitlements"')
    app = derived / "Build/Products/Release-iphonesimulator/SuperJLU.app"
    run("codesign", "--force", "--deep", "--sign", "-", str(app))
    info = plistlib.loads((app / "Info.plist").read_bytes())
    run("codesign", "--force", "--sign", "-", "--entitlements", str(entitlements), str(app))
    sections = run("otool", "-l", str(app / info["CFBundleExecutable"]), capture_output=True, text=True).stdout
    if "sectname __entitlements" not in sections:
        raise RuntimeError("Simulator entitlement section is missing")
    devices = json.loads(run("xcrun", "simctl", "list", "devices", "available", "-j",
                             capture_output=True, text=True).stdout)["devices"]
    candidates = [(runtime, device) for runtime, items in devices.items()
                  for device in items if device.get("isAvailable") and "iPhone" in device["name"]]
    if not candidates:
        raise RuntimeError("No available iPhone simulator")
    candidates.sort(key=lambda pair: ("iOS-18-5" not in pair[0], pair[0], pair[1]["name"]))
    runtime, device = candidates[0]
    udid = device["udid"]
    if device["state"] != "Booted":
        run("xcrun", "simctl", "boot", udid)
    run("xcrun", "simctl", "bootstatus", udid, "-b", timeout=240)
    run("xcrun", "simctl", "install", udid, str(app), timeout=120)
    container = Path(run("xcrun", "simctl", "get_app_container", udid,
                         info["CFBundleIdentifier"], "data", capture_output=True, text=True).stdout.strip())
    storage = container / "Library/Application Support/SuperJLU"
    try:
        env = dict(os.environ, SIMCTL_CHILD_SUPERJLU_SMOKE_TEST="1")
        for attempt in range(2):
            try:
                launch = subprocess.run(["xcrun", "simctl", "launch", udid, info["CFBundleIdentifier"]],
                    env=env, capture_output=True, text=True, timeout=120)
                print("SIMULATOR LAUNCH", launch.returncode, launch.stdout, launch.stderr, flush=True)
                launch.check_returncode()
                break
            except subprocess.TimeoutExpired:
                if (storage / "native-startup.log").is_file():
                    break
                if attempt:
                    raise
                print("Simulator launch service timed out; retrying after one warm reboot", flush=True)
                run("xcrun", "simctl", "shutdown", udid, timeout=60)
                run("xcrun", "simctl", "boot", udid, timeout=60)
                run("xcrun", "simctl", "bootstatus", udid, "-b", timeout=240)
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            if (storage / "smoke-result.json").is_file() and (storage / "webview-ready").is_file():
                report = json.loads((storage / "smoke-result.json").read_text())
                report.update(webview=True, simulator=device["name"], runtime=runtime,
                              physical_device_tested=False)
                (output / "simulator-report.json").write_text(json.dumps(report, indent=2))
                run("xcrun", "simctl", "io", udid, "screenshot", str(output / "simulator.png"))
                print("SIMULATOR SMOKE PASSED", json.dumps(report))
                return
            trace = storage / "native-startup.log"
            if trace.is_file() and "Python failed:" in trace.read_text():
                raise RuntimeError("Python startup failed; inspect simulator-diagnostics.log")
            time.sleep(2)
        raise RuntimeError("Native app did not finish startup; inspect simulator-diagnostics.log")
    except Exception:
        subprocess.run(["xcrun", "simctl", "io", udid, "screenshot", str(output / "simulator-failed.png")],
                       timeout=30, check=False)
        with (output / "simulator-diagnostics.log").open("w") as diagnostics:
            subprocess.run(["xcrun", "simctl", "spawn", udid, "log", "show", "--last", "5m",
                "--style", "compact", "--predicate", 'process == "SuperJLU" OR eventMessage CONTAINS "SuperJLU"'],
                stdout=diagnostics, stderr=subprocess.STDOUT, timeout=60, check=False)
            for path in (Path.home() / "Library/Logs/DiagnosticReports").glob("*SuperJLU*"):
                if path.is_file():
                    diagnostics.write("\nCRASH REPORT " + path.name + "\n" + path.read_text(errors="replace"))
            if storage.is_dir():
                diagnostics.write("\nSTORAGE FILES\n" + "\n".join(str(p.relative_to(storage)) for p in storage.rglob("*")))
        raise
    finally:
        trace = storage / "native-startup.log"
        if trace.is_file():
            shutil.copyfile(trace, output / "simulator-native-startup.log")
        subprocess.run(["xcrun", "simctl", "shutdown", udid], check=False, timeout=60)


if __name__ == "__main__":
    main()
