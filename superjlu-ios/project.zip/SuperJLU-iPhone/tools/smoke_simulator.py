"""Launch the native app in an iPhone simulator and check its embedded runtime."""
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def run(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def main():
    output = ROOT / "build"
    derived = output / "Simulator"
    run("xcodebuild", "-project", str(ROOT / "SuperJLU.xcodeproj"),
        "-scheme", "SuperJLU", "-configuration", "Debug", "-sdk", "iphonesimulator",
        "-destination", "generic/platform=iOS Simulator", "-derivedDataPath", str(derived),
        "build", "ARCHS=arm64", "ONLY_ACTIVE_ARCH=YES", "CODE_SIGNING_ALLOWED=NO",
        "CODE_SIGNING_REQUIRED=NO", "CODE_SIGN_IDENTITY=")
    app = derived / "Build/Products/Debug-iphonesimulator/SuperJLU.app"
    run("codesign", "--force", "--deep", "--sign", "-", str(app))
    info = plistlib.loads((app / "Info.plist").read_bytes())
    devices = json.loads(run("xcrun", "simctl", "list", "devices", "available", "-j",
                             capture_output=True, text=True).stdout)["devices"]
    candidates = [(runtime, device) for runtime, items in devices.items()
                  for device in items if device.get("isAvailable") and "iPhone" in device["name"]]
    if not candidates:
        raise RuntimeError("No available iPhone simulator")
    candidates.sort(key=lambda pair: ("iOS-18-5" not in pair[0], pair[0], pair[1]["name"]))
    runtime, device = candidates[0]
    udid = device["udid"]
    if device["state"] != "Booted":
        run("xcrun", "simctl", "boot", udid)
    run("xcrun", "simctl", "bootstatus", udid, "-b", timeout=240)
    run("xcrun", "simctl", "install", udid, str(app))
    container = Path(run("xcrun", "simctl", "get_app_container", udid,
                         info["CFBundleIdentifier"], "data", capture_output=True, text=True).stdout.strip())
    storage = container / "Library/Application Support/SuperJLU"
    try:
        env = dict(os.environ, SIMCTL_CHILD_SUPERJLU_SMOKE_TEST="1")
        launch = subprocess.run(["xcrun", "simctl", "launch", "--terminate-running-process",
            "--stdout=" + str(output / "simulator-stdout.log"),
            "--stderr=" + str(output / "simulator-runtime.log"), udid, info["CFBundleIdentifier"]],
            env=env, capture_output=True, text=True, timeout=120)
        print("SIMULATOR LAUNCH", launch.returncode, launch.stdout, launch.stderr, flush=True)
        launch.check_returncode()
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            if (storage / "smoke-result.json").is_file() and (storage / "webview-ready").is_file():
                report = json.loads((storage / "smoke-result.json").read_text())
                report.update(webview=True, simulator=device["name"], runtime=runtime,
                              physical_device_tested=False)
                (output / "simulator-report.json").write_text(json.dumps(report, indent=2))
                run("xcrun", "simctl", "io", udid, "screenshot", str(output / "simulator.png"))
                print("SIMULATOR SMOKE PASSED", json.dumps(report))
                return
            time.sleep(2)
        raise RuntimeError("Native app did not finish startup; inspect simulator-runtime.log")
    except Exception:
        subprocess.run(["xcrun", "simctl", "io", udid, "screenshot", str(output / "simulator-failed.png")],
                       timeout=30, check=False)
        with (output / "simulator-diagnostics.log").open("w") as diagnostics:
            subprocess.run(["xcrun", "simctl", "spawn", udid, "log", "show", "--last", "5m",
                "--style", "compact", "--predicate", 'process == "SuperJLU" OR eventMessage CONTAINS "SuperJLU"'],
                stdout=diagnostics, stderr=subprocess.STDOUT, timeout=60, check=False)
            for path in (Path.home() / "Library/Logs/DiagnosticReports").glob("*SuperJLU*"):
                if path.is_file():
                    diagnostics.write("\nCRASH REPORT " + path.name + "\n" + path.read_text(errors="replace"))
            if storage.is_dir():
                diagnostics.write("\nSTORAGE FILES\n" + "\n".join(str(p.relative_to(storage)) for p in storage.rglob("*")))
        raise
    finally:
        trace = storage / "native-startup.log"
        if trace.is_file():
            shutil.copyfile(trace, output / "simulator-native-startup.log")
        subprocess.run(["xcrun", "simctl", "shutdown", udid], check=False)


if __name__ == "__main__":
    main()
