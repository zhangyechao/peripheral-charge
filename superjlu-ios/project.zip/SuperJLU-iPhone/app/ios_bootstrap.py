"""iOS host for the recovered SuperJLU 1.3.4 Python application."""
from pathlib import Path
import os
import secrets
import sys
import threading
from http.server import ThreadingHTTPServer

_server = None
_url = None


def install_storage(native):
    """Keep upstream encrypted file format; use CryptoKit and iOS Keychain."""
    from jlu_toolkit import secure_store

    class AESGCM:
        def __init__(self, key):
            self.key = key

        def encrypt(self, nonce, data, associated_data):
            return native.encrypt(self.key, nonce, data, associated_data or b"")

        def decrypt(self, nonce, data, associated_data):
            return native.decrypt(self.key, nonce, data, associated_data or b"")

    def key(create):
        # Fail closed: never trigger upstream's plaintext fallback on iOS.
        result = native.key(bool(create))
        if result is None or len(result) != 32:
            raise secure_store.SecureStoreError("iPhone 钥匙串不可用，请解锁设备后重试。")
        return result

    secure_store._aesgcm = lambda: AESGCM
    secure_store._get_key = key
    secure_store._has_backend = lambda: True
    secure_store.backend_name = lambda: "iOS Keychain"


def adapted_page(page):
    # Retain original desktop/Android branches. Only extend the native ICS path.
    old = 'if(!/SuperJLU-Android/.test(navigator.userAgent))return;e.preventDefault();if(exportIcs.busy)'
    new = 'if(!/SuperJLU-(Android|iOS)/.test(navigator.userAgent))return;e.preventDefault();if(exportIcs.busy)'
    if old not in page:
        raise RuntimeError("APK interface differs from verified SuperJLU 1.3.4")
    page = page.replace(old, new, 1)
    page = page.replace("请从托盘或开始菜单重新打开 SuperJLU 后再登录",
                        "请关闭并重新打开 SuperJLU 后再登录")
    style = """<style>
    /* WKWebView already occupies the native safe area. */
    @supports (-webkit-touch-callout: none) {
      input,select,textarea {font-size:16px!important}
      html {-webkit-text-size-adjust:100%}
      #android-extras,#browser-preferences {display:none!important}
    }
    </style>"""
    return page.replace("</head>", style + "</head>", 1)


def start(storage_root, *, native=None, demo=False):
    global _server, _url
    if _server is not None:
        return _url
    if sys.version_info[:2] != (3, 13):
        raise RuntimeError("The supplied APK contains CPython 3.13 bytecode.")
    if native is None:
        import superjlu_native as native
    root = Path(storage_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    os.environ["XDG_CONFIG_HOME"] = str(root)
    os.environ["SSL_CERT_FILE"] = str(Path(__file__).with_name("cacert.pem"))
    os.environ["SUPERJLU_APP_VERSION"] = "1.3.4-ios.1"
    install_storage(native)
    import ios_ciphers
    ios_ciphers.configure(native)
    from jlu_toolkit import ui
    ui.PAGE = adapted_page(ui.PAGE)
    data = ui.data_dir()
    if demo:
        ui.seed_demo(data)
    # A new token per app process; never expose the server to the local network.
    token = secrets.token_urlsafe(32)
    handler = ui.make_handler(ui.Store(data), token=token)
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True,
                     name="SuperJLU-local").start()
    _server = server
    _url = ui.launch_url(f"http://127.0.0.1:{server.server_port}", token)
    if os.environ.get("SUPERJLU_SMOKE_TEST") == "1":
        import ios_smoke
        ios_smoke.check(root, native, _url)
    return _url


def stop():
    global _server, _url
    if _server:
        _server.shutdown()
        _server.server_close()
        _server = None
        _url = None
