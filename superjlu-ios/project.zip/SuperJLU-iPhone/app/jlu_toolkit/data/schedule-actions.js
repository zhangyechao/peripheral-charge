"use strict";

const schedulePanel = $("#t-kb");
const sheet = $("#schedule-sheet");
const sheetBody = $("#schedule-sheet-body");
let weekBlocks = [];

// Each palette supplies a light and dark surface, its text color, and the course's accent.
const courseColors = [
    ["#d8e6ff","#1d3967","#203451","#d2e3ff","#7398dc"],
    ["#ffdfd1","#65301e","#482f29","#ffdfd2","#da8c69"],
    ["#d4eddf","#204e3c","#213d32","#d0efdf","#6aa98e"],
    ["#e4dcfa","#493166","#392e49","#e8d9ff","#a18ac5"],
    ["#f6e6be","#594118","#423821","#f5e5c0","#b99b58"],
    ["#cfecee","#194d54","#1c3c40","#cef1f3","#67abb1"],
    ["#f5dae4","#663347","#4a2c38","#ffdeea","#c3839e"],
];
const schedulePrefs = {
    weekends: lsGet("jlu-schedule-weekends") !== "off",
    times: lsGet("jlu-schedule-times") !== "off",
    density: lsGet("jlu-schedule-density") === "compact" ? "compact" : "standard",
    sound: lsGet("jlu-water-sound") !== "off",
};

function weekDate(selectedWeek, weekday) {
    if (!D || !D.first_monday) return null;
    const first = new Date(String(D.first_monday).slice(0,10) + "T00:00:00");
    if (!Number.isFinite(first.getTime())) return null;
    first.setDate(first.getDate() + (selectedWeek - 1) * 7 + weekday - 1);
    return first;
}
const monthDay = date => (date.getMonth()+1) + "/" + date.getDate();

function drawWeekHeader(days, now) {
    const start = weekDate(week,1), end = weekDate(week,7);
    const term = D.calendar && D.calendar.term;
    $("#week-range").textContent = start ? monthDay(start) + " – " + monthDay(end) : term || "学期课表";
    const header = $("#week-days");
    header.replaceChildren();
    const month = document.createElement("span");
    month.className = "month";
    month.textContent = start ? (start.getMonth()+1) + "月" : "节次";
    header.append(month);
    for (let day = 1; day <= days; day++) {
        const date = weekDate(week,day), title = "周" + KB_WD[day-1];
        const button = document.createElement("button");
        button.type = "button";
        button.dataset.weekday = day;
        button.setAttribute("aria-label",(date ? monthDay(date) + " " : "") + title + "日程");
        if (date && date.toDateString() === now.toDateString()) button.setAttribute("aria-current","date");
        button.textContent = title;
        if (date) {
            const number = document.createElement("small");
            number.textContent = date.getDate();
            button.append(number);
        }
        header.append(button);
    }
}

function groupWeekCourses(courses, days) {
    const rows = courses.map((course,index) => ({course,index}))
        .filter(({course}) => course.weekday >= 1 && course.weekday <= days)
        .sort((a,b) => a.course.weekday-b.course.weekday || a.course.start-b.course.start || a.index-b.index);
    const blocks = [];
    for (const {course,index} of rows) {
        const last = blocks[blocks.length-1];
        if (last && last.day === course.weekday && course.start <= last.end) {
            last.end = Math.max(last.end,course.end);
            last.indices.push(index);
        } else {
            blocks.push({day:course.weekday,start:course.start,end:course.end,indices:[index]});
        }
    }
    return blocks;
}

function renderWeekTable(courses, periods, now) {
    const days = schedulePrefs.weekends ? 7 : 5;
    const lastPeriod = Math.max(11, ...Object.keys(periods).map(Number).filter(Number.isFinite), ...courses.map(c=>c.end));
    schedulePanel.dataset.weekend = schedulePrefs.weekends ? "on" : "off";
    schedulePanel.dataset.density = schedulePrefs.density;
    $("#grid").style.setProperty("--max-period", lastPeriod);
    drawWeekHeader(days,now);
    const currentDay = D.first_monday && week === weekOf(now) ? now.getDay() || 7 : 0;
    let html = "";
    for (let p = 1; p <= lastPeriod; p++) {
        const pair = periods[p] || [];
        html += '<div class="p" style="grid-row:' + p + '">' + p;
        if (schedulePrefs.times) {
            if (pair[0]) html += '<em>' + esc(pair[0]) + '</em>';
            if (pair[1]) html += '<em class="pe">' + esc(pair[1]) + '</em>';
        }
        html += '</div>';
        for (let d = 1; d <= days; d++) {
            html += '<div class="cell' + (d===currentDay ? ' current-day' : '') + '" data-d="' + d +
                '" data-p="' + p + '" style="grid-row:' + p + ';grid-column:' + (d+1) + '"></div>';
        }
    }
    weekBlocks = groupWeekCourses(courses,days);
    weekBlocks.forEach((block,i) => {
        const course = courses[block.indices.find(index=>courses[index].src!=="cancelled") ?? block.indices[0]];
        let hash = 0;
        for (const letter of course.name) hash = (31*hash + letter.charCodeAt(0)) >>> 0;
        const [light,ink,dark,night,accent] = courseColors[hash % courseColors.length];
        const count = block.indices.length, label = count > 1 ? "重叠 " + count + " 门课程，查看列表" : course.name + "，" + kbSlot(course);
        html += '<button type="button" class="cls' + kbCls(course) + '" data-i="' + i + '" aria-label="' + esc(label) +
            '" style="grid-column:' + (block.day+1) + ';grid-row:' + block.start + '/' + (block.end+1) +
            ';--tile-light:' + light + ';--ink-light:' + ink + ';--tile-dark:' + dark + ';--ink-dark:' + night + ';--tile-accent:' + accent +
            '">' + (count>1 ? '<span class="overlap">' + count + ' 门课</span>' : '') +
            '<b>' + esc(course.name) + '</b>' + (course.location ? '<i>' + esc(course.location) + '</i>' : '') + '</button>';
    });
    $("#grid").innerHTML = html;
}

$("#week-days").onclick = event => {
    const day = event.target.closest("[data-weekday]");
    if (!day || !D) return;
    agendaDay = Number(day.dataset.weekday);
    setScheduleView("day");
    lsSet("jlu-schedule-view","day");
    renderAgenda(KB_CS,periodMap(),new Date());
};

function showSheet(title, contents) {
    $("#schedule-sheet-title").textContent = title;
    sheetBody.innerHTML = contents;
    if (!sheet.open) sheet.showModal();
    sheet.scrollTop = 0;
}
function actionRow(action, title, detail = "") {
    return '<button class="sheet-row" type="button" data-action="' + action + '"><span><strong>' + esc(title) +
        '</strong>' + (detail ? '<small>' + esc(detail) + '</small>' : '') + '</span><span class="arrow" aria-hidden="true">›</span></button>';
}
function checkRow(key, name, value) {
    return '<label class="sheet-row"><strong>' + name + '</strong><input type="checkbox" data-pref="' + key + '"' + (value ? " checked" : "") + '></label>';
}
function openWeekCell(element) {
    const block = weekBlocks[Number(element.dataset.i)];
    if (!block) return;
    if (block.indices.length === 1) return kbOpen(KB_CS[block.indices[0]]);
    showSheet("重叠的课程",block.indices.map(i => {
        const c=KB_CS[i];
        return actionRow("course-" + i, c.name, [kbSlot(c),c.location,c.teacher].filter(Boolean).join(" · "));
    }).join(""));
}

$("#sheet-close").onclick = () => sheet.close();
$("#pick-week").onclick = () => {
    if (!D) return;
    const now = D.first_monday ? weekOf(new Date()) : null;
    const options = Array.from({length:maxWeek()}, (_,i) => {
        const n=i+1;
        return '<button type="button" aria-pressed="' + (n===week) + '"' + (n===now ? ' aria-current="date"' : '') +
            ' data-action="week-' + n + '">第 ' + n + ' 周</button>';
    }).join("");
    showSheet("选择教学周",'<div class="week-options">' + options + '</div>');
    sheetBody.querySelector('[aria-pressed="true"]').focus({preventScroll:true});
};
$("#open-import").onclick = () => {
    if (!D) return;
    showSheet("导入课表",actionRow("sync","从教务同步",LOGGED ? "使用当前账号" : "登录吉大统一身份认证") +
        actionRow("import","导入修改备份","SuperJLU 导出的 JSON 文件"));
};
$("#open-share").onclick = () => {
    if (!D) return;
    showSheet("分享课表",actionRow("share","分享本周课表","课程、节次和上课地点") +
        actionRow("calendar","导出到日历","整个学期的 ICS 文件") + actionRow("backup","导出修改备份","自定义课程、改课和停课记录"));
};
$("#open-display").onclick = () => {
    if (!D) return;
    showSheet("课表显示",checkRow("weekends","周表显示周末",schedulePrefs.weekends) +
        checkRow("times","显示每节起止时间",schedulePrefs.times) +
        '<label class="sheet-row"><strong>行高</strong><select data-pref="density"><option value="standard">标准</option><option value="compact">紧凑</option></select></label>' +
        checkRow("sound","主题切换水声",schedulePrefs.sound) + actionRow("term","学期与调课") + actionRow("edits","我的课表修改"));
    sheetBody.querySelector('[data-pref=density]').value=schedulePrefs.density;
};
sheetBody.addEventListener("change",event=>{
    switch(event.target.dataset.pref) {
    case "density": schedulePrefs.density=event.target.value; lsSet("jlu-schedule-density",schedulePrefs.density); break;
    case "times": schedulePrefs.times=event.target.checked; lsSet("jlu-schedule-times",schedulePrefs.times?"on":"off"); break;
    case "weekends": schedulePrefs.weekends=event.target.checked; lsSet("jlu-schedule-weekends",schedulePrefs.weekends?"on":"off"); break;
    case "sound": schedulePrefs.sound=event.target.checked; lsSet("jlu-water-sound",schedulePrefs.sound?"on":"off"); waterSwitch.setSound(schedulePrefs.sound,.36); syncSoundSetting(); return;
    default: return;
    }
    renderGrid();
});

function jumpToSettings(details) {
    document.querySelector('nav [data-t="sz"]').click();
    details.open=true;
    details.scrollIntoView({block:"center"});
}
function weekText() {
    const lines = ["SuperJLU · 第 " + week + " 周"];
    for(let d=1;d<=7;d++){
        const entries=KB_CS.filter(c=>c.weekday===d).sort((a,b)=>a.start-b.start);
        if(!entries.length) continue;
        const date=weekDate(week,d);
        lines.push("","周"+KB_WD[d-1]+(date?" "+monthDay(date):""));
        for(const c of entries) lines.push("第"+c.start+(c.start===c.end?"":"–"+c.end)+"节 "+c.name+(c.location?" · "+c.location:"")+(c.src==="cancelled"?"（停课）":""));
    }
    if(!KB_CS.length)lines.push("本周没有排课");
    return lines.join("\n");
}
sheetBody.addEventListener("click",async event=>{
    const button=event.target.closest("button[data-action]");
    if(!button)return;
    const action=button.dataset.action;
    if(action==="copy"){
        const field=$("#week-text");
        field.select();
        try { await navigator.clipboard.writeText(field.value);toast("已复制本周课表"); }
        catch {toast(document.execCommand("copy")?"已复制本周课表":"请长按文字复制");}
        return;
    }
    sheet.close();
    if(action.startsWith("week-")){week=Number(action.slice(5));renderGrid();return;}
    if(action.startsWith("course-")){kbOpen(KB_CS[Number(action.slice(7))]);return;}
    switch(action){
    case "sync": if(LOGGED) $("#refresh").click(); else openLogin(); break;
    case "import": $("#kb-import").click(); break;
    case "calendar": $("#ics").click(); break;
    case "backup": jumpToSettings($("#kb-edits-card")); $("#kb-export").click(); break;
    case "term": jumpToSettings($("#calinfo").closest("details")); break;
    case "edits": jumpToSettings($("#kb-edits-card")); break;
    case "share": {
        const text=weekText();
        if(window.SuperJLU && typeof SuperJLU.shareScheduleText==="function"){SuperJLU.shareScheduleText(text);return;}
        if(navigator.share){
            try{await navigator.share({title:"本周课表",text});return;}catch(error){if(error.name==="AbortError")return;}
        }
        showSheet("本周课表",'<textarea class="share-week-text" id="week-text" aria-label="本周课表文字" readonly rows="8"></textarea><button type="button" class="btn" data-action="copy" id="sheet-copy">复制文字</button>');
        $("#week-text").value=text;
        break;
    }}
});

function resolvedMode() {
    return document.documentElement.dataset.theme || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
}
const themeButton=$("#liquid-switch");
function syncThemeButton(){
    const mode=resolvedMode(), next=mode==="dark"?"浅色":"深色";
    themeButton.dataset.mode=mode;
    themeButton.setAttribute("aria-label","切换到"+next+"主题");
    themeButton.title="切换到"+next+"主题";
}
function syncSoundSetting(){ $("#water-sound").checked=schedulePrefs.sound; }
const waterSwitch=window.CodexLiquidTheme.mount({
    button:themeButton, getMode:resolvedMode, setMode:mode=>window.__setTheme(mode),
    duration:1750, sound:schedulePrefs.sound, volume:.36,
});
$("#water-sound").onchange=event=>{
    schedulePrefs.sound=event.target.checked;
    lsSet("jlu-water-sound",schedulePrefs.sound?"on":"off");
    waterSwitch.setSound(schedulePrefs.sound,.36);
};
new MutationObserver(syncThemeButton).observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
matchMedia("(prefers-color-scheme: dark)").addEventListener("change",syncThemeButton);
syncThemeButton();
syncSoundSetting();
startAcademicUI();
