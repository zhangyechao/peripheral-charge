/* A host supplies its existing theme getter and setter. No framework or build step. */
(() => {
  "use strict";

  const IMPACT = 0.31;
  
  const activeByDocument = new WeakMap();
  const limit = (value, low = 0, high = 1) => Math.max(low, Math.min(high, value));
  const ease = value => { const t = limit(value); return t * t * (3 - 2 * t); };
  const dec = value => Number(value.toFixed(2));

  function ellipse(x, y, rx, ry) {
    return `M${dec(x)} ${dec(y - ry)}a${dec(rx)} ${dec(ry)} 0 1 1 0 ${dec(2 * ry)}a${dec(rx)} ${dec(ry)} 0 1 1 0 ${dec(-2 * ry)}Z`;
  }

  function outline(t, width, height, x0, y0) {
    if (t <= 0) return "M0 0Z";
    if (t >= 0.985) return `M-2 -2H${width + 2}V${height + 2}H-2Z`;

    const fill = limit((t - IMPACT) / (0.966 - IMPACT));
    const fall = limit(t / IMPACT);
    const distance = Math.max(1, height - y0);
    const bottom = y0 + distance * fall * fall;
    const streamWidth = limit(width * 0.006, 3.1, 7.5);
    const poolHeight = (height + 28) * ease(fill);
    const amplitude = Math.min(16, height * 0.025) * ease(fill / 0.13) * (1 - ease((fill - 0.72) / 0.28));
    const spread = ease(fill / 0.35);
    const left = x0 - (x0 + 3) * spread;
    const right = x0 + (width + 3 - x0) * spread;
    const point = (x, y) => `${dec(x)} ${dec(y)}`;
    let path = "";

    if (fill > 0) {
      for (let i = 0; i <= 72; i++) {
        const x = left + (right - left) * i / 72;
        const dx = x - x0;
        const shore = 1 - (1 - spread) * Math.pow(Math.abs(dx) / (dx < 0 ? x0 + 3 : width + 3 - x0) / Math.max(spread, 0.0001), 2);
        const wave = 0.58 * Math.sin(x / 82 - 16 * t)
          + 0.28 * Math.sin(x / 43 + 19 * t)
          - 0.39 * Math.cos(Math.abs(dx) / 35 - 26 * t) * Math.exp(-Math.abs(dx) / 310);
        const y = Math.min(height + 1, height - poolHeight * shore + amplitude * wave);
        path += (i ? "L" : "M") + point(x, y);
      }
      path += `V${height + 3}H${dec(left)}Z`;
    }

    if (t < 0.85) {
      const taper = 1 - ease((t - 0.67) / 0.18);
      const length = Math.max(0.05, bottom - y0);
      const neck = ease(t / 0.045) * taper;
      const edges = [[], []];
      for (let i = 0; i <= 28; i++) {
        const h = i / 28;
        const y = y0 + length * h;
        const sway = Math.sin(h * 7.5 - t * 17) * Math.sin(h * Math.PI * 0.82) * streamWidth * 0.92;
        const radius = Math.max(0.07, streamWidth * (0.95 - 0.40 * h + 0.12 * Math.sin(h * 11 - t * 21)) * neck);
        edges[0].push(point(x0 + sway + radius, y));
        edges[1].push(point(x0 + sway - radius, y));
      }
      path += "M" + edges[0].join("L") + "L" + edges[1].reverse().join("L") + "Z";
      if (t < IMPACT) {
        const rad = Math.max(0.08, streamWidth * 0.79 * neck);
        path += ellipse(x0 + Math.sin(7.5 - t * 17) * streamWidth * 0.49, bottom, rad, rad * 1.26);
      }
    }

    // Detached beads stay just behind the leading tip. The spray starts at contact.
    for (let i = 0; i < 3; i++) {
      const p = (t - 0.042 - i * 0.042) / IMPACT;
      if (p <= 0 || p >= 1) continue;
      const r = streamWidth * (0.34 + i * 0.085) * Math.sin(Math.PI * p);
      const x = x0 + (i % 2 ? 1 : -1) * (7 + i * 2) * p;
      path += ellipse(x, y0 + distance * p * p, r, r * 1.55);
    }
    for (let i = 0; i < 10; i++) {
      const p = (t - IMPACT - (i % 3) * 0.008) / (0.105 + (i % 4) * 0.013);
      if (p <= 0 || p >= 1) continue;
      const x = x0 + (i % 2 ? 1 : -1) * (20 + i * 5.5) * p;
      const y = height - 4 * p * (1 - p) * (19 + (i % 4) * 9) - 1;
      const r = (1.7 + (i % 3) * 0.65) * Math.sin(p * Math.PI);
      path += ellipse(x, y, r, r * 1.23);
    }
    return path || "M0 0Z";
  }

  // The two local clips are rendered from the November 12 Water.cs synthesizer.
  // Arm while the tap is active, then align the first sample with the first frame.
  class WaterSound {
    constructor(enabled, volume) {
      this.clips = Object.fromEntries(["dark", "light"].map(mode => {
        const clip = new Audio("/water-" + mode + ".wav");
        clip.preload = enabled ? "auto" : "none";
        return [mode, clip];
      }));
      this.set(enabled, volume);
    }
    set(enabled, volume = this.volume) {
      this.enabled = Boolean(enabled);
      this.volume = limit(Number.isFinite(volume) ? volume : .36);
      for (const clip of Object.values(this.clips)) clip.volume = this.volume;
      if (!this.enabled || !this.volume) this.stop();
    }
    arm(mode) {
      if (!this.enabled || !this.volume) return;
      this.current = this.clips[mode];
      this.current.muted = true;
      this.current.currentTime = 0;
      this.current.play().catch(() => {});
    }
    start() {
      if (!this.current || !this.enabled) return;
      this.current.currentTime = 0;
      this.current.muted = false;
      this.current.play().catch(() => {});
    }
    stop() {
      if (this.current) this.current.pause();
      this.current = null;
    }
    dispose() { this.stop(); }
  }

  // Older WebViews still get the same liquid outline, cut out of a snapshot.
  // A native dialog lives on the top layer, outside the snapshot it contains.
  function snapshotLayer(doc) {
    const layer = doc.createElement("dialog");
    layer.className = "water-snapshot";
    layer.tabIndex = -1;
    const frame = doc.createElement("div");
    frame.className = "water-frame";
    frame.setAttribute("aria-hidden", "true");
    const copy = doc.createElement("div");
    copy.className = "water-copy";
    const live = Array.from(doc.body.children);
    for (const node of live) {
      if (node.matches("script,style,dialog,#toast")) continue;
      const clone = node.cloneNode(true);
      const originals = node.querySelectorAll("input,select,textarea,details");
      clone.querySelectorAll("input,select,textarea,details").forEach((field,index) => {
        const source = originals[index];
        if (field.tagName === "DETAILS") field.open = source.open;
        else {
          if (field.type !== "file") field.value = source.value;
          if ("checked" in field) field.checked = source.checked;
        }
      });
      if (node.matches("header,nav")) {
        const bounds = node.getBoundingClientRect();
        Object.assign(clone.style,{position:"absolute", margin:"0", top:bounds.top+"px",
          left:bounds.left+"px",width:bounds.width+"px",height:bounds.height+"px",right:"auto",bottom:"auto",transform:"none"});
        frame.append(clone);
      } else copy.append(clone);
    }
    const copyTop = doc.querySelector("main")?.getBoundingClientRect().top || 0;
    copy.style.transform = "translateY(" + copyTop + "px)";
    frame.append(copy);
    layer.append(frame);
    doc.body.append(layer);
    // Keeping original nodes first preserves the app's ID lookups for its entire lifetime.
    const focus = doc.activeElement;
    layer.show();
    if (focus?.isConnected) focus.focus({ preventScroll: true });
    return layer;
  }

  const transitionStyles = `
    @keyframes codex-liquid-hold { from { opacity: 1 } to { opacity: 1 } }
    .water-snapshot[open] { position:fixed; inset:0; box-sizing:border-box; width:100%; height:100%; max-width:none; max-height:none; margin:0; padding:0; border:0; z-index:2147483647; overflow:hidden; pointer-events:none; color:var(--txt); background:var(--bg); outline:none; }
    .water-frame { position:absolute; inset:0; overflow:hidden; } .water-copy { overflow:visible; }
    .water-snapshot .water-frame > header,.water-snapshot .water-frame > nav { z-index:8; }
    html[data-codex-liquid] * { view-transition-name: none !important }
    html[data-codex-liquid]::view-transition { pointer-events: none !important }
    html[data-codex-liquid]::view-transition-group(root),
    html[data-codex-liquid]::view-transition-image-pair(root) { animation: none !important }
    html[data-codex-liquid]::view-transition-old(root),
    html[data-codex-liquid]::view-transition-new(root) {
      animation: codex-liquid-hold 15s linear both !important;
      mix-blend-mode: normal !important; opacity: 1 !important;
    }
    html[data-codex-liquid]::view-transition-old(root) { z-index: 0 }
    html[data-codex-liquid]::view-transition-new(root) {
      z-index: 1; clip-path: var(--codex-liquid-mask) !important;
    }`;

  function mount({ button, getMode, setMode, duration = 1780, sound = false, volume = 0.24, onError = console.error }) {
    const doc = button.ownerDocument, win = doc.defaultView, root = doc.documentElement;
    const motion = win.matchMedia("(prefers-reduced-motion: reduce)");
    const audio = new WaterSound(sound, volume);
    const style = doc.createElement("style");
    style.textContent = transitionStyles;
    doc.head.append(style);
    let job = null, disposed = false;

    function quiet(action) { try { action(); } catch { audio.stop(); } }
    function interrupt() {
      if (!job) return;
      job.interrupted = true;
      audio.stop();
      job.transition?.skipTransition();
      job.resolveFrame?.();
    }
    function onPointer(event) { if (!button.contains(event.target)) interrupt(); }
    function onVisibility() { if (doc.hidden) { interrupt(); audio.stop(); } }
    function onKey(event) { if (event.key === "Escape") interrupt(); }
    doc.addEventListener("visibilitychange", onVisibility);

    async function toggle() {
      if (disposed || activeByDocument.has(doc)) return;
      const state = { frame: 0, interrupted: false };
      job = state;
      activeByDocument.set(doc, state);
      const listeners = new AbortController();
      let commitPromise;
      const mode = getMode() === "dark" ? "light" : "dark";
      try {
        audio.stop();
        const apply = () => {
          if (!commitPromise) commitPromise = Promise.resolve().then(() => { if (!disposed) return setMode(mode); });
          return commitPromise;
        };
        const box = button.getBoundingClientRect();
        const width = win.innerWidth, height = win.innerHeight;
        const x = limit(box.left + box.width / 2, 0, width);
        const y = limit(box.bottom - 2, 0, height);
        const nativeFrames = typeof doc.startViewTransition === "function";
        const canClip = win.CSS?.supports("clip-path", 'path("M0 0H1V1Z")');
        if (motion.matches || doc.hidden || !box.width || height - y < 5 || !canClip) {
          await apply();
          return;
        }
        quiet(() => audio.arm(mode));
        const signal = listeners.signal;
        win.addEventListener("resize", interrupt, { signal });
        win.addEventListener("pagehide", interrupt, { signal });
        win.addEventListener("blur", interrupt, { signal });
        win.visualViewport?.addEventListener("resize", interrupt, { signal });
        doc.addEventListener("scroll", interrupt, { capture: true, signal });
        doc.addEventListener("pointerdown", onPointer, { capture: true, signal });
        doc.addEventListener("beforeinput", interrupt, { capture: true, signal });
        doc.addEventListener("keydown", onKey, { capture: true, signal });
        motion.addEventListener("change", interrupt, { signal });
        root.setAttribute("data-codex-liquid", "");
        root.style.setProperty("--codex-liquid-mask", 'path("M0 0Z")');
        if (nativeFrames) {
          try {
            const transition = doc.startViewTransition(apply);
            state.transition = transition;
            transition.updateCallbackDone.catch(() => {});
            transition.finished.catch(() => {});
            await transition.ready;
          } catch {
            state.transition?.skipTransition();
            await apply();
            audio.stop();
            return;
          }
        } else {
          await apply();
          if (state.interrupted || disposed) return;
          // Render the new palette in a clipped copy above the original palette.
          const previous = mode === "dark" ? "light" : "dark";
          const layer = snapshotLayer(doc);
          state.layer = layer;
          const style = win.getComputedStyle(root);
          for (const name of ["pri","pri-h","pri2","bg","card","card2","txt","sub","line","ok","ok2","warn","warn2","bad","bad2","sh"])
            layer.style.setProperty("--"+name,style.getPropertyValue("--"+name));
          layer.dataset.waterMode = mode;
          layer.style.clipPath = 'path("M0 0Z")';
          // Only the visual palette is temporarily old. The stored choice is already committed.
          root.dataset.theme = previous;
          state.restoreTheme = () => { root.dataset.theme = mode; };
        }
        if (state.interrupted || disposed) return;
        const started = win.performance.now();
        const ms = limit(Number(duration) || 1780, 450, 4000);
        quiet(() => audio.start(mode));
        await new Promise(resolve => {
          state.resolveFrame = resolve;
          function draw(now) {
            if (state.interrupted || disposed) { resolve(); return; }
            const t = limit((now - started) / ms);
            const mask = `path("${outline(t, width, height, x, y)}")`;
            if (state.layer) state.layer.style.clipPath = mask;
            else root.style.setProperty("--codex-liquid-mask", mask);
            if (t < 1) state.frame = win.requestAnimationFrame(draw);
            else resolve();
          }
          state.frame = win.requestAnimationFrame(draw);
        });

      } catch (error) {
        audio.stop();
        if (!disposed) { await Promise.resolve(setMode(mode)).catch(() => {}); onError(error); }
      } finally {
        state.restoreTheme?.();
        state.layer?.remove();
        listeners.abort();
        win.cancelAnimationFrame(state.frame);
        state.transition?.skipTransition();
        if (state.transition) await state.transition.finished.catch(() => {});
        if (activeByDocument.get(doc) === state) {
          activeByDocument.delete(doc);
          root.removeAttribute("data-codex-liquid");
          root.style.removeProperty("--codex-liquid-mask");
        }
        if (job === state) job = null;
      }
    }
    button.addEventListener("click", toggle);
    return {
      toggle,
      setSound(enabled, level) { audio.set(enabled, level); },
      dispose() {
        disposed = true;
        interrupt();
        button.removeEventListener("click", toggle);
        doc.removeEventListener("visibilitychange", onVisibility);
        style.remove();
        audio.dispose();
      },
    };
  }
  window.CodexLiquidTheme = Object.freeze({ mount });
})();
