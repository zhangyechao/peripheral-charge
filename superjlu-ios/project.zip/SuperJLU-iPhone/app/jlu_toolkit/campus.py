"""Load the unchanged APK module with its three crypto imports redirected.

The original campus.pyc is retained. No fake cryptography package is installed;
only this module uses the narrowly scoped CommonCrypto compatibility adapter.
"""
from importlib.machinery import SourcelessFileLoader as _Loader
from pathlib import Path as _Path

_loader = _Loader(__name__, str(_Path(__file__).with_suffix(".pyc")))
_code = _loader.get_code(__name__)
_imports = {
    "cryptography.hazmat.primitives.ciphers",
    "cryptography.hazmat.primitives.ciphers.modes",
    "cryptography.hazmat.decrepit.ciphers.modes",
}
_code = _code.replace(co_names=tuple("ios_ciphers" if name in _imports else name
                                    for name in _code.co_names))
exec(_code, globals())
del _code, _imports, _loader, _Loader, _Path
