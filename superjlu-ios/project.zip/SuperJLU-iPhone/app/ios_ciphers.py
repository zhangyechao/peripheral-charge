"""Small AES-CFB adapter for the upstream WebVPN URL codec.

Only the Cipher/AES/CFB interface used by campus.pyc is supported. Actual
cryptography is performed by Apple's CommonCrypto through the native bridge.
"""
from types import SimpleNamespace

_native = None


def configure(native):
    global _native
    _native = native


class AES:
    def __init__(self, key):
        self.key = bytes(key)
        if len(self.key) not in (16, 24, 32):
            raise ValueError("Invalid AES key size")


class CFB:
    def __init__(self, initialization_vector):
        self.iv = bytes(initialization_vector)
        if len(self.iv) != 16:
            raise ValueError("CFB requires a 16-byte IV")


algorithms = SimpleNamespace(AES=AES)


class _Context:
    def __init__(self, key, iv, encrypt):
        self.key, self.iv, self.encrypt = key, iv, encrypt
        self.buffer = b""
        self.finished = False

    def update(self, data):
        if self.finished:
            raise ValueError("Cipher context has been finalized")
        if _native is None:
            raise RuntimeError("iOS cipher bridge has not been initialized")
        previous = len(self.buffer)
        self.buffer += bytes(data)
        # Hostnames are small. Reprocessing gives correct partial-block semantics
        # across multiple update() calls without keeping a native pointer alive.
        return _native.cfb(self.key, self.iv, self.buffer, self.encrypt)[previous:]

    def finalize(self):
        if self.finished:
            raise ValueError("Cipher context has been finalized")
        self.finished = True
        self.buffer = b""
        return b""


class Cipher:
    def __init__(self, algorithm, mode):
        if not isinstance(algorithm, AES) or not isinstance(mode, CFB):
            raise ValueError("Only AES-CFB is supported by this adapter")
        self.key, self.iv = algorithm.key, mode.iv

    def encryptor(self):
        return _Context(self.key, self.iv, True)

    def decryptor(self):
        return _Context(self.key, self.iv, False)
