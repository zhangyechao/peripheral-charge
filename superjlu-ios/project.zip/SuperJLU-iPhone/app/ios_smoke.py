"""Opt-in simulator checks. No real account or external network is used."""
import io
import json
from http.cookiejar import CookieJar
from urllib.request import build_opener, HTTPCookieProcessor


def check(root, native, url):
    from PIL import Image
    from jlu_toolkit import campus, secure_store
    key = native.key(True)
    assert len(key) == 32
    nonce, aad = bytes(12), b"native-smoke"
    sealed = native.encrypt(key, nonce, b"fixture", aad)
    assert native.decrypt(key, nonce, sealed, aad) == b"fixture"
    try:
        native.decrypt(key, nonce, sealed[:-1] + bytes([sealed[-1] ^ 1]), aad)
    except Exception:
        pass
    else:
        raise AssertionError("AES-GCM accepted a corrupted tag")
    # NIST SP 800-38A F.3.13 first CFB128 block.
    cfb_key = bytes.fromhex("2b7e151628aed2a6abf7158809cf4f3c")
    iv = bytes.fromhex("000102030405060708090a0b0c0d0e0f")
    plaintext = bytes.fromhex("6bc1bee22e409f96e93d7e117393172a")
    ciphertext = bytes.fromhex("3b3fd92eb72dad20333449f8e83cfb4a")
    assert native.cfb(cfb_key, iv, plaintext, True) == ciphertext
    assert native.cfb(cfb_key, iv, ciphertext, False) == plaintext
    school = "https://iedu.jlu.edu.cn/jwapp/test?q=1"
    assert campus.vpn_url_decode(campus.vpn_url(school)) == school
    secret = secure_store.SecretFile(root, "simulator-fixture")
    secret.save({"fixture": 1})
    assert secret.load() == {"fixture": 1}
    secret.delete()
    image = Image.new("RGB", (32, 16), "white")
    encoded = io.BytesIO()
    image.save(encoded, format="JPEG")
    assert Image.open(io.BytesIO(encoded.getvalue())).size == (32, 16)
    page = build_opener(HTTPCookieProcessor(CookieJar())).open(url, timeout=10).read()
    assert b"SuperJLU" in page
    (root / "smoke-result.json").write_text(json.dumps({
        "keychain": True, "aes_gcm": True, "aes_cfb": True,
        "webvpn_url_codec": True, "encrypted_file": True,
        "pillow_jpeg": True, "local_http": True,
    }), encoding="utf-8")
