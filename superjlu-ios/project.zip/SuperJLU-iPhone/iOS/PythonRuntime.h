#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface PythonRuntime : NSObject
+ (void)startWithCompletion:(void (^)(NSURL * _Nullable url, NSError * _Nullable error))completion;
@end
NS_ASSUME_NONNULL_END
