import Foundation
import CryptoKit
import Security

@objc(SJCrypto)
final class SJCrypto: NSObject {
    private static let lock = NSLock()

    @objc(loadKeyWithCreate:error:)
    static func loadKey(create: Bool) throws -> Data {
        lock.lock()
        defer { lock.unlock() }
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: (Bundle.main.bundleIdentifier ?? "SuperJLU") + ".storage",
            kSecAttrAccount as String: "aes256-v1",
        ]
        var read = query
        read[kSecReturnData as String] = true
        read[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(read as CFDictionary, &item)
        if status == errSecSuccess, let value = item as? Data, value.count == 32 { return value }
        guard status == errSecItemNotFound && create else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }
        var bytes = Data(count: 32)
        let randomStatus = bytes.withUnsafeMutableBytes {
            SecRandomCopyBytes(kSecRandomDefault, 32, $0.baseAddress!)
        }
        guard randomStatus == errSecSuccess else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(randomStatus))
        }
        var insert = query
        insert[kSecValueData as String] = bytes
        insert[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let add = SecItemAdd(insert as CFDictionary, nil)
        guard add == errSecSuccess else { throw NSError(domain: NSOSStatusErrorDomain, code: Int(add)) }
        return bytes
    }

    @objc(encryptWithKey:nonce:data:aad:error:)
    static func encrypt(key: Data, nonce: Data, data: Data, aad: Data) throws -> Data {
        let box = try AES.GCM.seal(data, using: SymmetricKey(data: key),
                                   nonce: AES.GCM.Nonce(data: nonce), authenticating: aad)
        return box.ciphertext + box.tag
    }

    @objc(decryptWithKey:nonce:data:aad:error:)
    static func decrypt(key: Data, nonce: Data, data: Data, aad: Data) throws -> Data {
        guard data.count >= 16 else { throw CocoaError(.fileReadCorruptFile) }
        let box = try AES.GCM.SealedBox(nonce: AES.GCM.Nonce(data: nonce),
                                       ciphertext: data.dropLast(16), tag: data.suffix(16))
        return try AES.GCM.open(box, using: SymmetricKey(data: key), authenticating: aad)
    }
}
