#define PY_SSIZE_T_CLEAN
#include <Python.h>
#import <CommonCrypto/CommonCryptor.h>
#import "PythonRuntime.h"
#import "SuperJLUiOS-Swift.h"

static PyObject *native_key(PyObject *self, PyObject *args) {
    int create;
    if (!PyArg_ParseTuple(args, "p", &create)) return NULL;
    @autoreleasepool {
        NSError *error = nil;
        NSData *data = [SJCrypto loadKeyWithCreate:create error:&error];
        if (!data) {
            PyErr_SetString(PyExc_RuntimeError, "iOS Keychain unavailable; no plaintext fallback");
            return NULL;
        }
        return PyBytes_FromStringAndSize(data.bytes, (Py_ssize_t)data.length);
    }
}

static PyObject *sj_crypt(PyObject *args, BOOL encrypt) {
    const char *k, *n, *d, *a;
    Py_ssize_t kl, nl, dl, al;
    if (!PyArg_ParseTuple(args, "y#y#y#y#", &k, &kl, &n, &nl, &d, &dl, &a, &al)) return NULL;
    @autoreleasepool {
        NSData *key = [NSData dataWithBytes:k length:kl];
        NSData *nonce = [NSData dataWithBytes:n length:nl];
        NSData *data = [NSData dataWithBytes:d length:dl];
        NSData *aad = [NSData dataWithBytes:a length:al];
        NSError *error = nil;
        NSData *result = encrypt
            ? [SJCrypto encryptWithKey:key nonce:nonce data:data aad:aad error:&error]
            : [SJCrypto decryptWithKey:key nonce:nonce data:data aad:aad error:&error];
        if (!result) {
            PyErr_SetString(PyExc_RuntimeError, "iOS AES-GCM operation failed");
            return NULL;
        }
        return PyBytes_FromStringAndSize(result.bytes, (Py_ssize_t)result.length);
    }
}
static PyObject *native_encrypt(PyObject *self, PyObject *args) { return sj_crypt(args, YES); }
static PyObject *native_decrypt(PyObject *self, PyObject *args) { return sj_crypt(args, NO); }
static PyObject *native_cfb(PyObject *self, PyObject *args) {
    const char *key, *iv, *data;
    Py_ssize_t kl, il, dl;
    int encrypt;
    if (!PyArg_ParseTuple(args, "y#y#y#p", &key, &kl, &iv, &il, &data, &dl, &encrypt)) return NULL;
    if ((kl != 16 && kl != 24 && kl != 32) || il != 16) {
        PyErr_SetString(PyExc_ValueError, "Invalid AES-CFB key or IV"); return NULL;
    }
    CCCryptorRef cryptor = NULL;
    CCCryptorStatus status = CCCryptorCreateWithMode(encrypt ? kCCEncrypt : kCCDecrypt,
        kCCModeCFB, kCCAlgorithmAES, ccNoPadding, iv, key, kl, NULL, 0, 0, 0, &cryptor);
    if (status != kCCSuccess) {
        PyErr_SetString(PyExc_RuntimeError, "CommonCrypto CFB initialization failed"); return NULL;
    }
    PyObject *result = PyBytes_FromStringAndSize(NULL, dl + kCCBlockSizeAES128);
    if (!result) { CCCryptorRelease(cryptor); return NULL; }
    size_t written = 0, final = 0;
    status = CCCryptorUpdate(cryptor, data, dl, PyBytes_AS_STRING(result),
        dl + kCCBlockSizeAES128, &written);
    if (status == kCCSuccess) status = CCCryptorFinal(cryptor,
        PyBytes_AS_STRING(result) + written, dl + kCCBlockSizeAES128 - written, &final);
    CCCryptorRelease(cryptor);
    if (status != kCCSuccess || written + final != (size_t)dl) {
        Py_DECREF(result); PyErr_SetString(PyExc_RuntimeError, "CommonCrypto CFB failed"); return NULL;
    }
    if (_PyBytes_Resize(&result, dl) < 0) return NULL;
    return result;
}
static PyMethodDef methods[] = {
    {"key", native_key, METH_VARARGS, "Retrieve an iOS Keychain key."},
    {"encrypt", native_encrypt, METH_VARARGS, "AES-256-GCM encryption."},
    {"decrypt", native_decrypt, METH_VARARGS, "Authenticated decryption."},
    {"cfb", native_cfb, METH_VARARGS, "AES-CFB for upstream WebVPN URL compatibility."},
    {NULL, NULL, 0, NULL}
};
static struct PyModuleDef module = {PyModuleDef_HEAD_INIT, "superjlu_native", NULL, -1, methods};
PyMODINIT_FUNC PyInit_superjlu_native(void) { return PyModule_Create(&module); }

@implementation PythonRuntime
+ (void)startWithCompletion:(void (^)(NSURL *, NSError *))completion {
    // One interpreter for the entire application lifetime.
    static dispatch_once_t once;
    static NSURL *launchURL;
    static NSError *launchError;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        dispatch_once(&once, ^{
            NSString *bundle = NSBundle.mainBundle.resourcePath;
            NSURL *storage = [[NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory
                inDomains:NSUserDomainMask].firstObject URLByAppendingPathComponent:@"SuperJLU" isDirectory:YES];
            NSError *directoryError = nil;
            [NSFileManager.defaultManager createDirectoryAtURL:storage withIntermediateDirectories:YES
                attributes:@{NSFileProtectionKey: NSFileProtectionComplete} error:&directoryError];
            if (directoryError) { launchError = directoryError; return; }
            // This cache is tied to a device-only Keychain key; do not back it up to iCloud.
            [storage setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
            if (PyImport_AppendInittab("superjlu_native", PyInit_superjlu_native) == -1) {
                launchError = [NSError errorWithDomain:@"SuperJLU" code:1 userInfo:nil]; return;
            }
            PyPreConfig pre;
            PyPreConfig_InitIsolatedConfig(&pre);
            pre.utf8_mode = 1;
            PyStatus status = Py_PreInitialize(&pre);
            if (PyStatus_Exception(status)) {
                launchError = [NSError errorWithDomain:@"SuperJLU" code:2 userInfo:nil]; return;
            }
            PyConfig config;
            PyConfig_InitIsolatedConfig(&config);
            config.buffered_stdio = 0;
            config.write_bytecode = 0;
            config.install_signal_handlers = 0; // Python is initialized off the UI thread.
            config.module_search_paths_set = 1;
            status = PyConfig_SetBytesString(&config, &config.home,
                [[bundle stringByAppendingPathComponent:@"python"] UTF8String]);
            NSArray *paths = @[@"python/lib/python3.13", @"python/lib/python3.13/lib-dynload", @"app", @"app_packages"];
            for (NSString *path in paths) {
                if (PyStatus_Exception(status)) break;
                wchar_t *wide = Py_DecodeLocale([[bundle stringByAppendingPathComponent:path] UTF8String], NULL);
                if (!wide) { status = PyStatus_NoMemory(); break; }
                status = PyWideStringList_Append(&config.module_search_paths, wide);
                PyMem_RawFree(wide);
            }
            if (!PyStatus_Exception(status)) status = Py_InitializeFromConfig(&config);
            PyConfig_Clear(&config);
            if (PyStatus_Exception(status)) {
                launchError = [NSError errorWithDomain:@"SuperJLU" code:3 userInfo:nil]; return;
            }
            PyObject *bootstrap = PyImport_ImportModule("ios_bootstrap");
            PyObject *result = bootstrap ? PyObject_CallMethod(bootstrap, "start", "s", storage.path.UTF8String) : NULL;
            if (result && PyUnicode_Check(result)) {
                const char *value = PyUnicode_AsUTF8(result);
                if (value) launchURL = [NSURL URLWithString:[NSString stringWithUTF8String:value]];
            }
            if (!launchURL) {
                PyErr_Print();
                launchError = [NSError errorWithDomain:@"SuperJLU" code:4 userInfo:nil];
            }
            Py_XDECREF(result);
            Py_XDECREF(bootstrap);
            PyEval_SaveThread(); // Allow the loopback server's Python threads to run.
        });
        dispatch_async(dispatch_get_main_queue(), ^{ completion(launchURL, launchError); });
    });
}
@end
