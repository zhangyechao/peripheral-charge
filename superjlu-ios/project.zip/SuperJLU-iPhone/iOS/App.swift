import UIKit
import WebKit
import SafariServices

private func smokeTrace(_ message: String) {
    guard ProcessInfo.processInfo.environment["SUPERJLU_SMOKE_TEST"] == "1" else { return }
    let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("SuperJLU", isDirectory: true)
    try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    let file = root.appendingPathComponent("native-startup.log")
    var data = (try? Data(contentsOf: file)) ?? Data()
    data.append(Data((message + "\n").utf8))
    try? data.write(to: file)
}

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions options: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        smokeTrace("AppDelegate started")
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = AppViewController()
        window?.makeKeyAndVisible()
        return true
    }
}

final class AppViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, WKDownloadDelegate {
    private var web: WKWebView!
    private var launchURL: URL?
    private var downloads: [ObjectIdentifier: URL] = [:]
    private let status = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        smokeTrace("View created; starting Python")
        view.backgroundColor = .systemBackground
        status.text = "正在启动 SuperJLU…"
        status.numberOfLines = 0
        status.textAlignment = .center
        status.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(status)
        NSLayoutConstraint.activate([
            status.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            status.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            status.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            status.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24)
        ])
        PythonRuntime.start { [weak self] url, error in
            smokeTrace(error == nil ? "Python start returned" : "Python failed: \(String(describing: error))")
            guard let self = self else { return }
            guard let url = url, error == nil else {
                self.status.text = "启动失败。请解锁 iPhone 后重新打开。\n若仍失败，请在 Xcode 查看 Python 启动日志。"
                return
            }
            self.launchURL = url
            self.makeWebView(url)
        }
    }

    private func makeWebView(_ url: URL) {
        let config = WKWebViewConfiguration()
        config.applicationNameForUserAgent = "SuperJLU-iOS"
        config.websiteDataStore = .default()
        let content = config.userContentController
        content.add(self, name: "superjlu")
        let script = """
        (() => {
          if (location.protocol !== 'http:' || location.hostname !== '127.0.0.1') return;
          const send = (type, text) => window.webkit.messageHandlers.superjlu.postMessage({type, text});
          window.SuperJLU = {
            appVersion: () => '1.3.4-ios.1',
            setBars: theme => send('theme', theme),
            shareIcs: text => send('ics', text),
            shareScheduleText: text => send('text', text)
          };
        })();
        """
        content.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.isOpaque = false
        web.backgroundColor = .systemBackground
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(web, belowSubview: status)
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        web.load(URLRequest(url: url))
    }

    private func isLocal(_ url: URL?) -> Bool {
        guard let url = url, let base = launchURL else { return false }
        return url.scheme == base.scheme && url.host == base.host && url.port == base.port
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        status.isHidden = true
        if ProcessInfo.processInfo.environment["SUPERJLU_SMOKE_TEST"] == "1", isLocal(webView.url) {
            let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("SuperJLU", isDirectory: true)
            try? Data("ready".utf8).write(to: root.appendingPathComponent("webview-ready"))
        }
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if let url = launchURL { webView.load(URLRequest(url: url)) }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code == NSURLErrorCancelled { return }
        status.text = "页面暂时无法打开，请关闭并重新打开应用。"
        status.isHidden = false
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        if isLocal(url) {
            decisionHandler(action.shouldPerformDownload ? .download : .allow)
        } else if url.absoluteString == "about:blank" {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
            // Keep third-party web pages outside the privileged app web view.
            if action.targetFrame?.isMainFrame != false { openExternal(url) }
        }
    }

    private func openExternal(_ url: URL) {
        guard presentedViewController == nil else { return }
        if ["https", "http"].contains(url.scheme ?? "") {
            present(SFSafariViewController(url: url), animated: true)
        } else if ["mailto", "tel"].contains(url.scheme ?? "") {
            UIApplication.shared.open(url)
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            if isLocal(url) { webView.load(navigationAction.request) } else { openExternal(url) }
        }
        return nil
    }

    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        let http = response.response as? HTTPURLResponse
        let attachment = http?.value(forHTTPHeaderField: "Content-Disposition")?.lowercased().contains("attachment") == true
        decisionHandler(response.isForMainFrame && (attachment || !response.canShowMIMEType) ? .download : .allow)
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { download.delegate = self }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { download.delegate = self }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, isLocal(message.frameInfo.request.url),
              let body = message.body as? [String: Any], let type = body["type"] as? String,
              let text = body["text"] as? String, text.utf8.count <= 5_000_000 else { return }
        switch type {
        case "theme":
            overrideUserInterfaceStyle = text == "dark" ? .dark : (text == "light" ? .light : .unspecified)
        case "ics":
            guard text.hasPrefix("BEGIN:VCALENDAR") else { return }
            do {
                let file = try shareDirectory().appendingPathComponent("jlu-schedule.ics")
                try Data(text.utf8).write(to: file, options: [.atomic, .completeFileProtection])
                share([file], cleanup: file.deletingLastPathComponent())
            } catch { showMessage("导出失败，请重试。") }
        case "text": share([text])
        default: break
        }
    }

    private func shareDirectory() throws -> URL {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }
    private func share(_ items: [Any], cleanup: URL? = nil) {
        guard presentedViewController == nil else { return }
        let sheet = UIActivityViewController(activityItems: items, applicationActivities: nil)
        sheet.popoverPresentationController?.sourceView = view
        sheet.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 30, width: 1, height: 1)
        sheet.completionWithItemsHandler = { _, _, _, _ in
            if let cleanup = cleanup { try? FileManager.default.removeItem(at: cleanup) }
        }
        present(sheet, animated: true)
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        do {
            let directory = try shareDirectory()
            let name = URL(fileURLWithPath: suggestedFilename).lastPathComponent
            let file = directory.appendingPathComponent(name.isEmpty || name == "." || name == ".." ? "export.dat" : name)
            downloads[ObjectIdentifier(download)] = file
            completionHandler(file)
        } catch { completionHandler(nil) }
    }
    func downloadDidFinish(_ download: WKDownload) {
        if let file = downloads.removeValue(forKey: ObjectIdentifier(download)) {
            share([file], cleanup: file.deletingLastPathComponent())
        }
    }
    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        if let file = downloads.removeValue(forKey: ObjectIdentifier(download)) {
            try? FileManager.default.removeItem(at: file.deletingLastPathComponent())
        }
        showMessage("下载失败，请重试。")
    }
    private func showMessage(_ message: String) {
        let alert = UIAlertController(title: "SuperJLU", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: "SuperJLU", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: "SuperJLU", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }
}
